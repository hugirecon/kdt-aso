# KDT Aso — Knowledge Base

Persistent facts about the operational environment.

---

### System (2026-02-18)
KDT Aso is an Autonomous Operations Platform deployed for Nigerian Defence Headquarters.

### Languages (2026-02-18)
System supports: English, Hausa, Yoruba, Igbo, Nigerian Pidgin, French, Arabic

### Organization (2026-02-18)
Knight Division Tactical (KDT) - U.S.-based defense technology company
- CEO: Michael Schulz
- COO: Matthew McCalla
